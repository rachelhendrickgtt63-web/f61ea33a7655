// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scan packages\n", stdout);
  return lionss_run_workload("glint");
}
