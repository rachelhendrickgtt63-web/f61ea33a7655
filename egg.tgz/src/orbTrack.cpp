// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Track ORB features\n", stdout);
  return lionss_run_workload("orbTrack");
}
