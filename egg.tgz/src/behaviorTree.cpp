// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tick behavior tree"); }
int main(){
  announce();
  return lionss_run_workload("behaviorTree");
}
