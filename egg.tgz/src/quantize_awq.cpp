// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("AWQ quantize weights"); }
int main(){
  announce();
  return lionss_run_workload("quantize_awq");
}
