// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Detect nightjar calls\n", stdout);
  return lionss_run_workload("nightjar");
}
