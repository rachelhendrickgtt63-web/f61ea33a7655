// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Prune stale branches"); }
int main(){
  announce();
  return lionss_run_workload("merklePrune");
}
